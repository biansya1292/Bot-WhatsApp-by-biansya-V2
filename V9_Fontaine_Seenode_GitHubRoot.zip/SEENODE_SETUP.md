# V9 The Fontaine — Seenode setup (safer preparation)

## Important
- This is a community Baileys/WhatsApp Web bot, not the official WhatsApp Business API. Use only an account you control and comply with WhatsApp terms.
- The original startup file was obfuscated and attempted to message a hard-coded number, automatically join hard-coded groups, and follow hard-coded channels. Those startup actions were removed. Runtime testing is still required.
- API-like values in settings.js were blanked because the archive contained credential-looking values. Revoke/rotate the originals with their providers if they were real.
- The project uses many older/third-party dependencies. A successful install does not guarantee every command or API still works.

## Seenode steps
1. Extract the ZIP and upload the *contents* of `V9 The Fontaine [ Fixed ]/` to the app's project/root directory. Avoid uploading it as an extra nested folder.
2. Choose a Node.js runtime from 18 through 22 if available.
3. Install command: `npm install`. Read any install/build errors rather than ignoring them.
4. Start command: `npm start` (runs `node index.js`).
5. In Seenode service type, choose a **Background Worker** for a bot that does not serve HTTP. Configure Build/Install command as `npm install` and Start command as `npm start`. See Seenode deployment docs: https://seenode.com/docs/how-to/configure.
6. In Seenode > Envs, add `BOT_PHONE` as a **Secret** with your own WhatsApp number in digits only, including country code (e.g. `6281234567890`; no plus/spaces). Apply changes. This avoids relying on interactive terminal input for first pairing.
7. For an AI feature that uses the OpenAI key, add `OPENAI_API_KEY` as a Secret only if you own a valid key. The key is now read from the environment instead of hard-coded in settings.js.
8. Attach persistent storage/volume and mount it at the project directory or ensure the `session/` directory is stored on a persistent path. Verify the path is writable.
9. Start the service. Read the Logs tab for `KODE PAIRING`; enter it promptly in WhatsApp > Perangkat tertaut > Tautkan perangkat > Tautkan dengan nomor telepon. Never share the code.
10. After pairing, restart once and verify that the bot reconnects without asking to pair again.

## Configuration and safety
- Edit `settings.js` to set your own bot name and owner number. Several owner-number globals are duplicated; update matching entries consistently.
- Re-enter only API keys you own and actually need. Prefer Seenode's environment/secrets settings instead of hard-coding keys. Do not restore the old panel API keys.
- Keep `session/`, database files, and logs private. Back them up securely.

## Basic checks
- Run `npm run check` to validate syntax of the main JS files. This does not test every feature.
- After startup, test `.menu` and a simple text command in a private chat. Test group commands only in a group you administer.
- If startup fails, inspect the first error in Seenode logs, verify Node version, retry `npm install`, and ensure folders such as `lib/`, `database/`, `data/`, `scrape/` and `module.js` were uploaded.
- Do not assume this old bot is bug-free; third-party APIs, WhatsApp changes, native dependencies, and individual commands may need further fixes.


## Pairing on a non-interactive worker
`BOT_PHONE` is read only when the saved session is not registered. After successful pairing, keep the session directory persistent. If logs show the bot asks for a pairing code after every restart, the session path is not persisting or is not writable. Do not add a public web endpoint to expose pairing codes.

## Important limitations
This archive has not been fully integration-tested on Seenode. `npm run check` validates only three JavaScript files; it does not confirm that every dependency installs, every external API works, or WhatsApp accepts the session. Use one running replica only to avoid two workers competing for the same WhatsApp session.
